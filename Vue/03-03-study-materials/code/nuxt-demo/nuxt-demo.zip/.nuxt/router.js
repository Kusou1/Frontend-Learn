import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _2fed80df = () => interopDefault(import('..\\pages\\layout' /* webpackChunkName: "" */))
const _35b93858 = () => interopDefault(import('..\\pages\\home' /* webpackChunkName: "" */))
const _80fd41d8 = () => interopDefault(import('..\\pages\\login' /* webpackChunkName: "" */))
const _84668ad8 = () => interopDefault(import('..\\pages\\profile' /* webpackChunkName: "" */))
const _e5eaaed0 = () => interopDefault(import('..\\pages\\settings' /* webpackChunkName: "" */))
const _241ea722 = () => interopDefault(import('..\\pages\\editor' /* webpackChunkName: "" */))
const _b6d2043e = () => interopDefault(import('..\\pages\\article' /* webpackChunkName: "" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/",
    component: _2fed80df,
    children: [{
      path: "",
      component: _35b93858,
      name: "home"
    }, {
      path: "/login",
      component: _80fd41d8,
      name: "login"
    }, {
      path: "/register",
      component: _80fd41d8,
      name: "register"
    }, {
      path: "/profile/:username",
      component: _84668ad8,
      name: "profile"
    }, {
      path: "/settings",
      component: _e5eaaed0,
      name: "settings"
    }, {
      path: "/editor",
      component: _241ea722,
      name: "editor"
    }, {
      path: "/article/:slug",
      component: _b6d2043e,
      name: "article"
    }]
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
